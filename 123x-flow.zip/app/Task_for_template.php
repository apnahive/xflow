<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Task_for_template extends Model
{
    //
}
