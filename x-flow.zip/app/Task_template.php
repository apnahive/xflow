<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Task_template extends Model
{
    //
}
