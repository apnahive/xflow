<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Form_sign extends Model
{
    //
}
