<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Checklist_template extends Model
{
    //
}
