<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Project_form extends Model
{
    //
}
