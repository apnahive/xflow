<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Project_file extends Model
{
    //
}
