<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Checklist_for_template extends Model
{
    //
}
