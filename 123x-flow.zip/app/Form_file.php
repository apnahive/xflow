<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Form_file extends Model
{
    //
}
